# bruise > 2023-05-18 3:10am
https://universe.roboflow.com/nabeel-alanbar-2vn5y/bruise-x5paj

Provided by a Roboflow user
License: CC BY 4.0

